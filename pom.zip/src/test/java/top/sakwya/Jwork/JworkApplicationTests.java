package top.sakwya.Jwork;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JworkApplicationTests {

	@Test
	void contextLoads() {
	}

}
